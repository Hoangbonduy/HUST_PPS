# Tên Dự Án
Code cho môn phương pháp số tại Đại học Bách khoa Hà Nội

## Cài đặt
pip install HUST_PPS

### Cập nhật
-0.2.0
+ Thêm hàm tính đa thực nội suy Newton, Newton mốc cách đều
+ Thêm hàm tính đa thức nội suy Lagrange mốc cách đều
+ Thêm hàm tính tỷ sai phân, sai phân tiến, sai phân lùi