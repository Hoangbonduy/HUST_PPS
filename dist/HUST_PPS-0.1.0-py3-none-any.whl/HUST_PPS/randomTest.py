def RandomTest():
    print("Hàm đã được gọi!")